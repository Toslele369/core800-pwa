# Core 800 PWA

自用手机端核心词汇学习应用。第一版包含 800 个核心高频词，支持美式音标、词性、汉译、例句、艾宾浩斯复习、红名单、日历、统计、离线使用、JSON/CSV 导出导入，以及 iPhone 与电脑之间的 Supabase 云同步。

## 功能

- 每天 40 个新词，共 20 组。
- 每组按学习后的第 1、2、4、7、15 天自动进入复习队列。
- 用 `0 / 1 / 2` 记录回忆结果：
  - `0`：忘记。
  - `1`：提示后想起。
  - `2`：直接答对。
- 0/1 词自动进入次日红名单回测。
- 单词闪卡可以隐藏或显示释义、例句，并播放美式发音。
- 今日任务、词库搜索、学习日历、进度统计和逐词笔记。
- 新概念第1册 144 课、第2册 96 课的自有词汇和短句复习。
- 新概念内容支持逐课添加、CSV 批量导入和课程内容导出。
- PWA 可添加到 iPhone 主屏幕，首次加载后可离线使用。
- 完整 JSON 备份和 Excel/WPS 可打开的进度 CSV。
- Supabase 邮箱账号云同步，数据只允许当前登录用户访问。

## 部署为手机可访问的网站

PWA 必须通过 HTTPS 网站访问，iPhone 才能稳定安装到主屏幕。项目没有构建步骤，直接把 `core800-pwa` 目录作为静态网站发布即可。

### 方式一：Cloudflare Pages 拖拽发布

1. 登录 Cloudflare Dashboard。
2. 进入 Workers & Pages → Create → Pages → Upload assets。
3. 上传 `core800-pwa` 目录中的内容。
4. 获得 `https://...pages.dev` 地址。
5. 在 iPhone Safari 中打开该地址，分享 → 添加到主屏幕。

### 方式二：Netlify Drop

1. 打开 `https://app.netlify.com/drop`。
2. 将 `core800-pwa` 目录或压缩包拖入页面。
3. 使用生成的 HTTPS 地址打开。
4. 在 iPhone Safari 中添加到主屏幕。

### 方式三：任意静态 HTTPS 服务器

把整个目录上传到 GitHub Pages、Vercel、对象存储网站托管或自己的服务器。必须保留目录结构，尤其是：

- `manifest.webmanifest`
- `service-worker.js`
- `words-data.js`
- `icons/`

## 配置 Supabase 多设备同步

当前版本支持多用户注册。每个账号拥有独立的学习快照，数据库通过 RLS 限制为只能访问自己的记录；同一台设备切换账号时，本机缓存也按用户 ID 分开保存。

### 1. 创建项目

在 [Supabase](https://supabase.com/) 创建自己的项目。免费项目足够保存这 800 词的评分、历史和笔记。

### 2. 创建数据表

打开 Supabase Dashboard → SQL Editor，执行 [schema.sql](./supabase/schema.sql) 的全部内容。

建表脚本会创建用户资料表、学习快照表、自动资料触发器和 Row Level Security 策略。数据库只允许当前登录用户读取和修改自己的数据：

- 手机和电脑必须登录同一个邮箱账号。
- 应用只使用 `anon public key`，不要使用 `service_role key`。
- 数据访问由 Row Level Security 限制为 `auth.uid() = user_id`。

### 3. 配置邮箱登录

在 Authentication → Providers → Email 中启用邮箱密码登录。

如果希望注册后立即登录，可以关闭邮件确认；如果保留邮件确认，需要先点击 Supabase 发来的确认邮件，再返回应用登录。

### 4. 填入应用

在 Supabase Project Settings → API 中复制：

- Project URL
- anon public key

把这两项填入 [config.js](./config.js)，然后重新发布网站：

```js
window.CORE800_CONFIG = {
  supabaseUrl: 'https://你的项目.supabase.co',
  supabaseAnonKey: '你的 anon public key'
};
```

这样普通用户只需要填写邮箱和密码注册，不需要理解 Supabase 技术配置。`config.js` 会缓存到 PWA；更新这两项后应关闭并重新打开应用，必要时同时修改 `service-worker.js` 的 `CACHE_NAME`。

之后每次评分、记笔记和完成会话，应用会延迟约 3 秒自动同步。离线时记录继续保存在本机，恢复网络后自动合并并上传。

## 数据与冲突策略

- 词库是只读数据，不参与同步。
- 每张单词卡保留独立的复习历史事件。
- 手机和电脑的复习事件按唯一事件 ID 合并。
- 已完成复习阶段取并集，避免一台设备覆盖另一台设备的进度。
- 最近一次评分决定红名单状态。
- 笔记和收藏按最近修改时间合并。
- 云同步失败不会阻断本机学习。

## 新概念课程内容

应用提供第1册 144 课、第2册 96 课的课程结构，但不内置受版权保护的教材课文、词汇表或短句。你可以导入自己整理的学习内容。

CSV 模板见 [nce-import-template.csv](./nce-import-template.csv)，列含义：

| 列 | 说明 |
|---|---|
| `book` | `1` 或 `2`，也可以使用 `nce1`、`nce2` |
| `lesson` | 第几课 |
| `type` | `word` 表示单词/短语，`sentence` 表示短句 |
| `english` | 英文内容 |
| `chinese` | 中文含义 |
| `ipa` | 可选的音标 |
| `pos` | 可选的词性 |
| `example` | 可选的补充例句 |

导入后，每一项仍然使用 0/1/2 评分和 1/2/4/7/15 天复习曲线。课程内容会随完整学习状态一起云同步。

## 备份

设置页提供两种导出：

- JSON：完整状态，可重新导入恢复。
- CSV：包含 800 词的当前进度，方便 Excel/WPS 查看。

清理 Safari 网站数据、卸载主屏幕应用或更换手机前，先导出 JSON。

## 本地检查

直接用浏览器打开 `index.html` 可以体验界面和学习逻辑。PWA 安装和 Service Worker 离线缓存需要通过 `localhost` 或 HTTPS 访问。

## 后续扩展 IELTS

词库数据包含 `book` 字段，每张卡也有独立的 `wordId`。下一版可以增加：

- IELTS 核心词库。
- 学术写作主题词。
- 听力场景词。
- 同义替换和搭配。
- 按 IELTS 目标分与错词类型筛选。

现有学习记录不需要迁移。
