-- Core 800 PWA cloud sync
-- Run this once in your private Supabase project's SQL Editor.

create table if not exists public.study_snapshots (
  user_id uuid primary key references auth.users(id) on delete cascade,
  payload jsonb not null,
  updated_at timestamptz not null default now()
);

alter table public.study_snapshots enable row level security;

drop policy if exists "users read own snapshot" on public.study_snapshots;
create policy "users read own snapshot"
on public.study_snapshots for select
using (auth.uid() = user_id);

drop policy if exists "users insert own snapshot" on public.study_snapshots;
create policy "users insert own snapshot"
on public.study_snapshots for insert
with check (auth.uid() = user_id);

drop policy if exists "users update own snapshot" on public.study_snapshots;
create policy "users update own snapshot"
on public.study_snapshots for update
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

grant select, insert, update on public.study_snapshots to authenticated;
