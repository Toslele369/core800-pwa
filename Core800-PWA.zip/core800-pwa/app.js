(() => {
  'use strict';

  const WORDS = Array.isArray(window.CORE_WORDS) ? window.CORE_WORDS : [];
  const WORD_BY_ID = new Map(WORDS.map((word) => [word.id, word]));
  const WORDS_BY_DAY = new Map();
  const INTERVALS = [1, 2, 4, 7, 15];
  const STORAGE_KEY = 'core800.pwa.state.v1';
  const SYNC_CONFIG_KEY = 'core800.pwa.sync.config.v1';
  const AUTH_KEY = 'core800.pwa.sync.auth.v1';
  const INSTALL_DISMISSED_KEY = 'core800.pwa.install.dismissed.v1';
  const MAX_SESSION_DUE = 320;

  for (const word of WORDS) {
    if (!WORDS_BY_DAY.has(word.day)) WORDS_BY_DAY.set(word.day, []);
    WORDS_BY_DAY.get(word.day).push(word);
  }

  const main = document.getElementById('main');
  const syncPill = document.getElementById('syncPill');
  const syncPillText = document.getElementById('syncPillText');
  const offlineBanner = document.getElementById('offlineBanner');
  const installBanner = document.getElementById('installBanner');
  const modalRoot = document.getElementById('modalRoot');
  const toastElement = document.getElementById('toast');

  const ui = {
    view: 'today',
    session: null,
    libraryQuery: '',
    libraryFilter: 'all',
    libraryLimit: 80,
    calendarCursor: startOfMonth(new Date()),
    selectedCalendarDate: todayISO(),
    syncStatus: 'local',
    syncError: '',
    syncTimer: null,
    deferredInstallPrompt: null,
    toastTimer: null
  };

  let state = loadState();
  let auth = loadAuth();

  function todayISO() {
    return dateToISO(new Date());
  }

  function dateToISO(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  function parseISODate(value) {
    const [year, month, day] = String(value).split('-').map(Number);
    return new Date(year, (month || 1) - 1, day || 1, 12, 0, 0, 0);
  }

  function addDaysISO(value, days) {
    const date = parseISODate(value);
    date.setDate(date.getDate() + days);
    return dateToISO(date);
  }

  function startOfMonth(date) {
    return new Date(date.getFullYear(), date.getMonth(), 1, 12, 0, 0, 0);
  }

  function startOfDay(date) {
    return new Date(date.getFullYear(), date.getMonth(), date.getDate(), 12, 0, 0, 0);
  }

  function daysBetween(startISO, endISO) {
    return Math.round((parseISODate(endISO) - parseISODate(startISO)) / 86400000);
  }

  function localDateFromTimestamp(timestamp) {
    return dateToISO(new Date(timestamp));
  }

  function formatLongDate(value = new Date()) {
    const date = typeof value === 'string' ? parseISODate(value) : value;
    return new Intl.DateTimeFormat('zh-CN', {
      month: 'long',
      day: 'numeric',
      weekday: 'long'
    }).format(date);
  }

  function formatShortDate(value) {
    const date = typeof value === 'string' ? parseISODate(value) : value;
    return new Intl.DateTimeFormat('zh-CN', {
      month: 'numeric',
      day: 'numeric'
    }).format(date);
  }

  function formatDateTime(timestamp) {
    if (!timestamp) return '尚未学习';
    return new Intl.DateTimeFormat('zh-CN', {
      month: 'numeric',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(new Date(timestamp));
  }

  function uid() {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') {
      return window.crypto.randomUUID();
    }
    return `id-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  }

  function escapeHTML(value) {
    return String(value ?? '')
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }

  function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }

  function lastValue(values) {
    return values.length ? values[values.length - 1] : null;
  }

  function defaultState() {
    const now = new Date().toISOString();
    return {
      version: 1,
      createdAt: now,
      updatedAt: now,
      settingsUpdatedAt: now,
      settings: {
        startDate: todayISO(),
        voiceRate: 0.88,
        selectedBook: 'core800'
      },
      cards: {},
      sessions: []
    };
  }

  function normalizeState(input) {
    const base = defaultState();
    if (!input || typeof input !== 'object') return base;
    return {
      ...base,
      ...input,
      settings: { ...base.settings, ...(input.settings || {}) },
      cards: input.cards && typeof input.cards === 'object' ? input.cards : {},
      sessions: Array.isArray(input.sessions) ? input.sessions : []
    };
  }

  function loadState() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? normalizeState(JSON.parse(raw)) : defaultState();
    } catch (error) {
      console.warn('Could not load saved state', error);
      return defaultState();
    }
  }

  function saveState() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }

  function loadJSON(key, fallback = null) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch {
      return fallback;
    }
  }

  function loadSyncConfig() {
    return loadJSON(SYNC_CONFIG_KEY, { url: '', key: '', email: '' });
  }

  function saveSyncConfig(config) {
    localStorage.setItem(SYNC_CONFIG_KEY, JSON.stringify({
      url: config.url.trim().replace(/\/+$/, ''),
      key: config.key.trim(),
      email: config.email.trim()
    }));
  }

  function loadAuth() {
    return loadJSON(AUTH_KEY, null);
  }

  function saveAuth(value) {
    auth = value;
    if (value) {
      localStorage.setItem(AUTH_KEY, JSON.stringify(value));
    } else {
      localStorage.removeItem(AUTH_KEY);
    }
    updateSyncPill();
  }

  function ensureCard(wordId) {
    if (!state.cards[wordId]) {
      state.cards[wordId] = {
        wordId,
        learnedAt: null,
        learningDay: null,
        completedStages: [],
        reviewHistory: [],
        lastScore: null,
        lastReviewedAt: null,
        redDueAt: null,
        errorCount: 0,
        starred: false,
        notes: '',
        updatedAt: new Date().toISOString()
      };
    }
    const card = state.cards[wordId];
    card.completedStages = Array.isArray(card.completedStages) ? card.completedStages : [];
    card.reviewHistory = Array.isArray(card.reviewHistory) ? card.reviewHistory : [];
    return card;
  }

  function isLearned(wordId) {
    return Boolean(state.cards[wordId]?.learnedAt);
  }

  function pendingOffsets(card, onDate = todayISO()) {
    if (!card?.learnedAt) return [];
    const completed = new Set(card.completedStages || []);
    return INTERVALS.filter((offset) => {
      return addDaysISO(card.learnedAt, offset) <= onDate && !completed.has(offset);
    });
  }

  function isRedDue(card, onDate = todayISO()) {
    return Boolean(card?.redDueAt && card.redDueAt <= onDate);
  }

  function isDue(card, onDate = todayISO()) {
    return pendingOffsets(card, onDate).length > 0 || isRedDue(card, onDate);
  }

  function getDueWords(onDate = todayISO()) {
    return WORDS.filter((word) => isDue(state.cards[word.id], onDate));
  }

  function getRedWords() {
    return WORDS
      .filter((word) => state.cards[word.id]?.lastScore != null && state.cards[word.id].lastScore < 2)
      .sort((a, b) => {
        const cardA = state.cards[a.id];
        const cardB = state.cards[b.id];
        return (cardB.errorCount || 0) - (cardA.errorCount || 0) || a.day - b.day || a.no - b.no;
      });
  }

  function getNextLearningDay() {
    for (let day = 1; day <= 20; day++) {
      const words = WORDS_BY_DAY.get(day) || [];
      if (words.some((word) => !isLearned(word.id))) return day;
    }
    return null;
  }

  function getNewWords(day = getNextLearningDay()) {
    if (!day) return [];
    return (WORDS_BY_DAY.get(day) || []).filter((word) => !isLearned(word.id));
  }

  function getWordStatus(word) {
    const card = state.cards[word.id];
    if (!card?.learnedAt) return 'new';
    if (card.lastScore != null && card.lastScore < 2) return 'red';
    if ((card.completedStages || []).length >= INTERVALS.length && card.lastScore === 2) return 'mastered';
    return 'learning';
  }

  function getLearnedCount() {
    return WORDS.filter((word) => isLearned(word.id)).length;
  }

  function getMasteredCount() {
    return WORDS.filter((word) => getWordStatus(word) === 'mastered').length;
  }

  function getAllHistory() {
    return WORDS.flatMap((word) => state.cards[word.id]?.reviewHistory || []);
  }

  function getAccuracy() {
    const history = getAllHistory();
    if (!history.length) return 0;
    return Math.round((history.filter((entry) => entry.score === 2).length / history.length) * 100);
  }

  function getStudyDates() {
    return new Set(getAllHistory().map((entry) => localDateFromTimestamp(entry.at)));
  }

  function getStreak() {
    const dates = getStudyDates();
    let cursor = todayISO();
    if (!dates.has(cursor)) cursor = addDaysISO(cursor, -1);
    let streak = 0;
    while (dates.has(cursor)) {
      streak++;
      cursor = addDaysISO(cursor, -1);
    }
    return streak;
  }

  function sessionLabel(mode) {
    if (mode === 'new') return '新词学习';
    if (mode === 'review') return '到期复习';
    if (mode === 'red') return '红名单回测';
    return '单词复习';
  }

  function mergeReviewHistories(a = [], b = []) {
    const map = new Map();
    for (const entry of [...a, ...b]) {
      if (!entry) continue;
      const id = entry.id || `${entry.at}-${entry.score}-${entry.mode}`;
      const existing = map.get(id);
      if (!existing || String(entry.at) > String(existing.at)) {
        map.set(id, { ...entry, id });
      }
    }
    return [...map.values()].sort((x, y) => String(x.at).localeCompare(String(y.at)));
  }

  function mergeCard(localCard, remoteCard) {
    if (!localCard) return remoteCard;
    if (!remoteCard) return localCard;
    const localNewer = String(localCard.updatedAt || '') >= String(remoteCard.updatedAt || '');
    const latest = localNewer ? localCard : remoteCard;
    const history = mergeReviewHistories(localCard.reviewHistory, remoteCard.reviewHistory);
    const lastEvent = history[history.length - 1] || null;
    const learnedAt = [localCard.learnedAt, remoteCard.learnedAt].filter(Boolean).sort()[0] || null;
    return {
      ...remoteCard,
      ...localCard,
      learnedAt,
      learningDay: localCard.learningDay ?? remoteCard.learningDay ?? null,
      completedStages: [...new Set([...(localCard.completedStages || []), ...(remoteCard.completedStages || [])])].sort((a, b) => a - b),
      reviewHistory: history,
      lastScore: lastEvent ? lastEvent.score : (latest.lastScore ?? null),
      lastReviewedAt: lastEvent?.at || latest.lastReviewedAt || null,
      redDueAt: lastEvent
        ? (lastEvent.score < 2 ? addDaysISO(localDateFromTimestamp(lastEvent.at), 1) : null)
        : latest.redDueAt || null,
      errorCount: history.filter((entry) => entry.score < 2).length,
      starred: Boolean(latest.starred),
      notes: latest.notes || '',
      updatedAt: lastValue([localCard.updatedAt, remoteCard.updatedAt].filter(Boolean).sort()) || new Date().toISOString()
    };
  }

  function mergeSessions(a = [], b = []) {
    const map = new Map();
    for (const session of [...a, ...b]) {
      if (!session) continue;
      const id = session.id || `${session.startedAt}-${session.mode}`;
      map.set(id, { ...session, id });
    }
    return [...map.values()].sort((x, y) => String(x.startedAt || '').localeCompare(String(y.startedAt || '')));
  }

  function mergeStates(localState, remoteState) {
    const local = normalizeState(localState);
    const remote = normalizeState(remoteState);
    const localSettingsNewer = String(local.settingsUpdatedAt || local.updatedAt) >= String(remote.settingsUpdatedAt || remote.updatedAt);
    const cards = {};
    const ids = new Set([...Object.keys(local.cards), ...Object.keys(remote.cards)]);
    for (const id of ids) {
      cards[id] = mergeCard(local.cards[id], remote.cards[id]);
    }
    return {
      ...local,
      createdAt: [local.createdAt, remote.createdAt].filter(Boolean).sort()[0],
      updatedAt: lastValue([local.updatedAt, remote.updatedAt].filter(Boolean).sort()),
      settingsUpdatedAt: lastValue([local.settingsUpdatedAt, remote.settingsUpdatedAt].filter(Boolean).sort()),
      settings: localSettingsNewer ? local.settings : remote.settings,
      cards,
      sessions: mergeSessions(local.sessions, remote.sessions)
    };
  }

  function applyGrade(wordId, score, mode) {
    const word = WORD_BY_ID.get(wordId);
    if (!word) return;
    const card = ensureCard(wordId);
    const now = new Date().toISOString();
    const today = todayISO();
    const dueOffsets = pendingOffsets(card, today);

    if (!card.learnedAt) {
      card.learnedAt = today;
      card.learningDay = word.day;
    }
    card.completedStages = [...new Set([...(card.completedStages || []), ...dueOffsets])].sort((a, b) => a - b);
    card.reviewHistory = mergeReviewHistories(card.reviewHistory, [{
      id: uid(),
      at: now,
      date: today,
      score,
      mode,
      dueOffsets
    }]);
    card.lastScore = score;
    card.lastReviewedAt = now;
    card.redDueAt = score < 2 ? addDaysISO(today, 1) : null;
    card.errorCount = card.reviewHistory.filter((entry) => entry.score < 2).length;
    card.updatedAt = now;
    state.updatedAt = now;
    saveState();
    queueSync();
  }

  function toggleStar(wordId) {
    const card = ensureCard(wordId);
    card.starred = !card.starred;
    card.updatedAt = new Date().toISOString();
    state.updatedAt = card.updatedAt;
    saveState();
    queueSync();
    return card.starred;
  }

  function saveNotes(wordId, notes) {
    const card = ensureCard(wordId);
    card.notes = String(notes || '').trim();
    card.updatedAt = new Date().toISOString();
    state.updatedAt = card.updatedAt;
    saveState();
    queueSync();
  }

  function showToast(message, duration = 2600) {
    toastElement.textContent = message;
    toastElement.classList.add('show');
    clearTimeout(ui.toastTimer);
    ui.toastTimer = setTimeout(() => toastElement.classList.remove('show'), duration);
  }

  function updateOnlineStatus() {
    offlineBanner.hidden = navigator.onLine;
  }

  function updateSyncPill() {
    const configured = Boolean(loadSyncConfig().url && loadSyncConfig().key);
    syncPill.classList.remove('online', 'syncing', 'error');
    if (ui.syncStatus === 'syncing') {
      syncPill.classList.add('syncing');
      syncPillText.textContent = '同步中';
      return;
    }
    if (ui.syncStatus === 'error') {
      syncPill.classList.add('error');
      syncPillText.textContent = '同步失败';
      return;
    }
    if (auth) {
      syncPill.classList.add('online');
      syncPillText.textContent = ui.syncStatus === 'synced' ? '已同步' : '云同步';
      return;
    }
    syncPillText.textContent = configured ? '待登录' : '仅本机';
  }

  // Supabase sync is implemented below. It uses only the public anon key and
  // row-level security; the sync password itself is never stored.
  async function supabaseRequest(path, options = {}, retry = true) {
    const config = loadSyncConfig();
    if (!config.url || !config.key) throw new Error('尚未填写 Supabase 配置');
    if (auth?.expires_at && Date.now() / 1000 > auth.expires_at - 90) {
      await refreshAuth();
    }
    const headers = {
      apikey: config.key,
      'Content-Type': 'application/json',
      ...(options.headers || {})
    };
    if (options.auth !== false && auth?.access_token) {
      headers.Authorization = `Bearer ${auth.access_token}`;
    }
    const response = await fetch(`${config.url}${path}`, { ...options, headers });
    if (response.status === 401 && retry) {
      await refreshAuth();
      return supabaseRequest(path, options, false);
    }
    if (!response.ok) {
      let detail = '';
      try {
        const body = await response.json();
        detail = body.msg || body.message || body.error_description || body.error || '';
      } catch {
        detail = response.statusText;
      }
      throw new Error(detail || `请求失败 (${response.status})`);
    }
    if (response.status === 204) return null;
    const text = await response.text();
    return text ? JSON.parse(text) : null;
  }

  async function refreshAuth() {
    const config = loadSyncConfig();
    if (!auth?.refresh_token) throw new Error('登录已过期，请重新登录');
    const response = await fetch(`${config.url}/auth/v1/token?grant_type=refresh_token`, {
      method: 'POST',
      headers: {
        apikey: config.key,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ refresh_token: auth.refresh_token })
    });
    if (!response.ok) {
      saveAuth(null);
      throw new Error('登录已过期，请重新登录');
    }
    const data = await response.json();
    const nextAuth = {
      access_token: data.access_token,
      refresh_token: data.refresh_token || auth.refresh_token,
      expires_at: data.expires_at || Math.floor(Date.now() / 1000) + (data.expires_in || 3600),
      user: data.user || auth.user
    };
    saveAuth(nextAuth);
    return nextAuth;
  }

  async function authenticate(email, password, signup = false) {
    const config = loadSyncConfig();
    if (!config.url || !config.key) throw new Error('请先填写 Supabase 项目地址和 anon key');
    if (!email || !password) throw new Error('请输入邮箱和密码');

    const path = signup
      ? '/auth/v1/signup'
      : '/auth/v1/token?grant_type=password';
    const response = await fetch(`${config.url}${path}`, {
      method: 'POST',
      headers: {
        apikey: config.key,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ email, password })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      throw new Error(data.msg || data.message || data.error_description || `登录失败 (${response.status})`);
    }
    if (signup && !data.session) {
      showToast('注册成功，请先到邮箱确认，再回来登录。', 5000);
      return false;
    }
    const sessionData = data.session || data;
    saveAuth({
      access_token: sessionData.access_token,
      refresh_token: sessionData.refresh_token,
      expires_at: sessionData.expires_at || Math.floor(Date.now() / 1000) + (sessionData.expires_in || 3600),
      user: sessionData.user || data.user
    });
    ui.syncStatus = 'online';
    return true;
  }

  async function syncNow(options = {}) {
    const { silent = false } = options;
    if (!auth) {
      if (!silent) showToast('请先在设置中登录云同步。');
      return false;
    }
    if (!navigator.onLine) {
      if (!silent) showToast('当前离线，联网后再同步。');
      return false;
    }
    ui.syncStatus = 'syncing';
    ui.syncError = '';
    updateSyncPill();
    if (!silent && ui.view === 'settings') render();

    try {
      const userId = auth.user?.id;
      if (!userId) throw new Error('同步账号信息不完整，请重新登录');
      const rows = await supabaseRequest(
        `/rest/v1/study_snapshots?user_id=eq.${encodeURIComponent(userId)}&select=payload,updated_at&limit=1`
      );
      if (Array.isArray(rows) && rows[0]?.payload) {
        state = mergeStates(state, rows[0].payload);
      }
      state.updatedAt = new Date().toISOString();
      saveState();
      await supabaseRequest('/rest/v1/study_snapshots?on_conflict=user_id', {
        method: 'POST',
        headers: { Prefer: 'resolution=merge-duplicates,return=minimal' },
        body: JSON.stringify([{
          user_id: userId,
          payload: state,
          updated_at: state.updatedAt
        }])
      });
      ui.syncStatus = 'synced';
      updateSyncPill();
      if (!silent) showToast('云端同步完成。');
      if (ui.view === 'settings' || ui.view === 'progress') render();
      return true;
    } catch (error) {
      ui.syncStatus = 'error';
      ui.syncError = error.message || String(error);
      updateSyncPill();
      if (!silent) showToast(`同步失败：${ui.syncError}`, 5000);
      if (ui.view === 'settings') render();
      return false;
    }
  }

  function queueSync() {
    if (!auth) return;
    clearTimeout(ui.syncTimer);
    ui.syncTimer = setTimeout(() => syncNow({ silent: true }), 2800);
  }

  function setView(view) {
    if (ui.session) {
      ui.session = null;
      document.body.classList.remove('studying');
    }
    ui.view = view;
    document.querySelectorAll('.nav-item').forEach((button) => {
      button.classList.toggle('active', button.dataset.nav === view);
    });
    render();
    window.scrollTo({ top: 0, behavior: 'smooth' });
    main.focus({ preventScroll: true });
  }

  function render() {
    updateSyncPill();
    updateInstallBanner();
    if (ui.session) {
      renderStudy();
      return;
    }
    document.body.classList.remove('studying');
    if (ui.view === 'library') {
      renderLibrary();
    } else if (ui.view === 'calendar') {
      renderCalendar();
    } else if (ui.view === 'progress') {
      renderProgress();
    } else if (ui.view === 'settings') {
      renderSettings();
    } else {
      renderToday();
    }
    document.querySelectorAll('.nav-item').forEach((button) => {
      button.classList.toggle('active', button.dataset.nav === ui.view);
    });
  }

  function pageHeader(eyebrow, title, subtitle = '') {
    return `
      <div class="page-head">
        <div>
          <p class="eyebrow">${escapeHTML(eyebrow)}</p>
          <h1 class="page-title">${escapeHTML(title)}</h1>
          ${subtitle ? `<p class="page-subtitle">${escapeHTML(subtitle)}</p>` : ''}
        </div>
      </div>
    `;
  }

  function renderToday() {
    const nextDay = getNextLearningDay();
    const newWords = getNewWords(nextDay);
    const dueWords = getDueWords();
    const redWords = getRedWords();
    const learned = getLearnedCount();
    const allLearned = nextDay === null;
    const todayLearned = WORDS.filter((word) => state.cards[word.id]?.learnedAt === todayISO()).length;
    const dueOffsets = [1, 2, 4, 7, 15].map((offset) => ({
      offset,
      count: dueWords.filter((word) => pendingOffsets(state.cards[word.id]).includes(offset)).length
    })).filter((item) => item.count > 0);

    let heroTitle = '今天先完成一次回忆';
    let heroMeta = '每天 40 个新词，复习采用 0 / 1 / 2 评分。';
    if (newWords.length) {
      heroTitle = `第 ${nextDay} 组 · 还有 ${newWords.length} 个新词`;
      heroMeta = `${WORDS_BY_DAY.get(nextDay)?.[0]?.group || ''} ${WORDS_BY_DAY.get(nextDay)?.[0]?.topic || ''} · 今日已新学 ${todayLearned} 词`;
    } else if (allLearned) {
      heroTitle = dueWords.length ? '进入维护复习阶段' : '800 词已全部进入复习系统';
      heroMeta = dueWords.length ? '今天以到期检索和红名单回测为主。' : '下一次到期时，应用会自动提醒你。';
    }

    main.innerHTML = `
      ${pageHeader('CORE 800', '保持回忆，持续积累', formatLongDate())}
      <div class="today-layout">
        <div>
          <section class="hero-card">
            <div class="hero-kicker">Today’s focus</div>
            <h2 class="hero-title">${escapeHTML(heroTitle)}</h2>
            <p class="hero-meta">${escapeHTML(heroMeta)}</p>
            <div class="hero-stats">
              <div class="hero-stat"><strong>${dueWords.length}</strong><span>今日到期</span></div>
              <div class="hero-stat"><strong>${redWords.length}</strong><span>红名单</span></div>
              <div class="hero-stat"><strong>${learned}</strong><span>已学 / 800</span></div>
            </div>
            <div class="hero-actions">
              ${
                newWords.length
                  ? `<button class="primary-button" data-action="start-new">学习新词</button>`
                  : `<button class="primary-button" data-action="start-review" ${dueWords.length ? '' : 'disabled'}>开始复习</button>`
              }
              <button class="secondary-button" data-action="${dueWords.length ? 'start-review' : redWords.length ? 'start-red' : 'go-library'}">
                ${dueWords.length ? `复习 ${dueWords.length}` : redWords.length ? '打开红名单' : '浏览词库'}
              </button>
            </div>
          </section>

          <section class="section">
            <div class="section-head">
              <h2>今日任务</h2>
              <small>${state.settings.startDate ? `计划起点 ${formatShortDate(state.settings.startDate)}` : ''}</small>
            </div>
            <div class="task-grid">
              <button class="task-card ${newWords.length ? '' : 'done'}" data-action="${newWords.length ? 'start-new' : 'go-library'}">
                <span class="task-icon">A</span>
                <span class="task-copy">
                  <strong>${newWords.length ? `新学 D${nextDay}` : '新词组已完成'}</strong>
                  <span>${newWords.length ? `${WORDS_BY_DAY.get(nextDay)?.[0]?.topic || ''} · ${newWords.length} 词` : '进入到期复习与输出阶段'}</span>
                </span>
                <span class="task-arrow">›</span>
              </button>
              <button class="task-card review ${dueWords.length ? '' : 'done'}" data-action="${dueWords.length ? 'start-review' : 'go-calendar'}">
                <span class="task-icon">R</span>
                <span class="task-copy">
                  <strong>${dueWords.length ? `到期复习 ${dueWords.length} 词` : '今日暂无到期'}</strong>
                  <span>${dueOffsets.length ? dueOffsets.map((item) => `+${item.offset}天 ${item.count}`).join(' · ') : '查看未来复习安排'}</span>
                </span>
                <span class="task-arrow">›</span>
              </button>
              <button class="task-card red ${redWords.length ? '' : 'done'}" data-action="${redWords.length ? 'start-red' : 'go-progress'}">
                <span class="task-icon">!</span>
                <span class="task-copy">
                  <strong>红名单 ${redWords.length} 词</strong>
                  <span>${redWords.length ? '最近一次回忆未直接答对' : '暂无需要额外回测的词'}</span>
                </span>
                <span class="task-arrow">›</span>
              </button>
            </div>
          </section>
        </div>

        <aside class="sticky-column">
          <section class="panel">
            <h3 class="panel-title">
              <span>当前状态</span>
              <span class="chip teal">${getStreak()} 天连续</span>
            </h3>
            <div class="stats-strip">
              <div class="stat-box"><strong>${Math.round((learned / 800) * 100)}%</strong><span>已学进度</span></div>
              <div class="stat-box"><strong>${getAccuracy()}%</strong><span>累计正确率</span></div>
              <div class="stat-box"><strong>${getMasteredCount()}</strong><span>完整掌握</span></div>
              <div class="stat-box"><strong>${todayLearned}</strong><span>今日新学</span></div>
            </div>
          </section>

          <section class="panel">
            <h3 class="panel-title">
              <span>复习节奏</span>
              <span class="chip gold">0/1/2 评分</span>
            </h3>
            <p class="panel-copy">每组词按学习后的第 1、2、4、7、15 天进入到期队列。评 0 或 1 的词会在次日进入红名单回测。</p>
            <div class="stage-chips" style="margin-top: 12px">
              ${[1, 2, 4, 7, 15].map((offset) => `<span class="chip">+${offset} 天</span>`).join('')}
            </div>
          </section>

          <section class="panel">
            <h3 class="panel-title">
              <span>同步</span>
              <span class="chip ${auth ? 'teal' : ''}">${auth ? '已登录' : '本机保存'}</span>
            </h3>
            <p class="panel-copy">${auth ? escapeHTML(auth.user?.email || '已连接云端') : '学习记录会自动保存在本机；登录 Supabase 后可在 iPhone 和电脑间同步。'}</p>
            <div class="button-row" style="margin-top: 13px">
              <button class="secondary-button" data-action="${auth ? 'sync-now' : 'go-settings'}">${auth ? '立即同步' : '设置云同步'}</button>
            </div>
          </section>
        </aside>
      </div>
    `;
  }

  function startStudy(mode) {
    let words = [];
    if (mode === 'new') {
      words = getNewWords();
    } else if (mode === 'review') {
      words = getDueWords().slice(0, MAX_SESSION_DUE);
    } else if (mode === 'red') {
      words = getRedWords();
    }
    if (!words.length) {
      showToast(mode === 'new' ? '新词已全部学完。' : '当前没有需要学习的词。');
      return;
    }
    speakStop();
    ui.session = {
      id: uid(),
      mode,
      words: words.map((word) => word.id),
      index: 0,
      revealed: false,
      startedAt: new Date().toISOString(),
      scores: [0, 0, 0],
      complete: false
    };
    document.body.classList.add('studying');
    renderStudy();
  }

  function renderStudy() {
    const session = ui.session;
    if (!session) return;
    document.body.classList.add('studying');
    updateInstallBanner();
    if (session.complete) {
      renderStudyComplete();
      return;
    }
    const wordId = session.words[session.index];
    const word = WORD_BY_ID.get(wordId);
    if (!word) {
      finishStudySession();
      return;
    }
    const card = state.cards[wordId] || null;
    const pending = pendingOffsets(card);
    const redDue = isRedDue(card);
    const progress = Math.round((session.index / session.words.length) * 100);
    const reason = session.mode === 'new'
      ? '首次学习'
      : pending.length
        ? `R${pending.join(' / R')}`
        : redDue
          ? '红名单'
          : '回忆';

    main.innerHTML = `
      <div class="study-shell">
        <div class="study-top">
          <button class="icon-button" data-action="exit-study" aria-label="退出学习">←</button>
          <div class="study-progress" aria-hidden="true"><span style="width:${progress}%"></span></div>
          <span class="study-count">${session.index + 1} / ${session.words.length}</span>
        </div>

        <article class="flashcard ${session.revealed ? 'revealed' : ''}">
          <div class="flashcard-main">
            <span class="word-label">D${word.day} · ${escapeHTML(word.group)} · ${escapeHTML(reason)}</span>
            <h1 class="word-main">${escapeHTML(word.word)}</h1>
            <p class="word-ipa">${escapeHTML(word.ipa)}</p>
            <button class="speaker-button" data-action="speak" data-word="${escapeHTML(word.word)}">
              <span aria-hidden="true">▶</span> 播放发音
            </button>

            <div class="flashcard-answer">
              <p class="answer-meaning"><span class="answer-pos">${escapeHTML(word.pos)}</span>${escapeHTML(word.meaning)}</p>
              <p class="answer-example">${escapeHTML(word.example)}</p>
            </div>

            ${!session.revealed ? '<p class="reveal-hint">先在脑中回忆词义，再查看答案</p>' : ''}
          </div>
          <div class="flashcard-controls">
            ${
              session.revealed
                ? `<div class="grade-grid">
                    <button class="grade-button" data-action="grade" data-score="0"><strong>0</strong><span>忘记</span></button>
                    <button class="grade-button" data-action="grade" data-score="1"><strong>1</strong><span>提示后想起</span></button>
                    <button class="grade-button" data-action="grade" data-score="2"><strong>2</strong><span>直接答对</span></button>
                  </div>`
                : `<button class="primary-button reveal-button" data-action="reveal">显示答案</button>`
            }
          </div>
        </article>
      </div>
    `;
  }

  function revealStudyAnswer() {
    if (!ui.session) return;
    ui.session.revealed = true;
    renderStudy();
  }

  function gradeCurrentWord(score) {
    const session = ui.session;
    if (!session || !session.revealed) return;
    const wordId = session.words[session.index];
    applyGrade(wordId, score, session.mode);
    session.scores[score]++;
    session.index++;
    session.revealed = false;
    if (session.index >= session.words.length) {
      finishStudySession();
    } else {
      renderStudy();
    }
  }

  function finishStudySession() {
    const session = ui.session;
    if (!session) return;
    if (!session.complete) {
      session.complete = true;
      session.completedAt = new Date().toISOString();
      state.sessions.push({
        id: session.id,
        mode: session.mode,
        date: todayISO(),
        startedAt: session.startedAt,
        completedAt: session.completedAt,
        total: session.words.length,
        scores: [...session.scores],
        wordIds: [...session.words]
      });
      state.updatedAt = session.completedAt;
      saveState();
      queueSync();
    }
    renderStudyComplete();
  }

  function renderStudyComplete() {
    const session = ui.session;
    if (!session) return;
    const total = session.words.length;
    const direct = session.scores[2];
    const rate = total ? Math.round((direct / total) * 100) : 0;
    const title = session.mode === 'new' ? '本组新词完成' : '这一轮回忆完成';
    main.innerHTML = `
      <div class="study-shell study-complete">
        <div>
          <div class="result-ring">${rate}%</div>
          <h1>${title}</h1>
          <p>直接答对 ${direct} 词 · 提示后答对 ${session.scores[1]} 词 · 忘记 ${session.scores[0]} 词</p>
          <div class="button-row" style="justify-content:center">
            <button class="primary-button" data-action="exit-study">回到今日</button>
            <button class="secondary-button" data-action="${session.mode === 'new' && getNextLearningDay() ? 'start-next-new' : getDueWords().length ? 'start-review' : 'go-progress'}">
              ${session.mode === 'new' && getNextLearningDay() ? '继续下一组' : getDueWords().length ? '继续复习' : '查看进度'}
            </button>
          </div>
        </div>
      </div>
    `;
  }

  function exitStudy() {
    speakStop();
    ui.session = null;
    document.body.classList.remove('studying');
    renderToday();
  }

  function speak(text) {
    if (!('speechSynthesis' in window)) {
      showToast('当前浏览器不支持语音朗读。');
      return;
    }
    speakStop();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'en-US';
    utterance.rate = clamp(Number(state.settings.voiceRate) || 0.88, 0.5, 1.25);
    const voices = window.speechSynthesis.getVoices();
    const preferred = voices.find((voice) => /en-US/i.test(voice.lang) && /Samantha|Alex|Ava|Allison|Serena/i.test(voice.name))
      || voices.find((voice) => /en-US/i.test(voice.lang))
      || voices.find((voice) => /^en/i.test(voice.lang));
    if (preferred) utterance.voice = preferred;
    window.speechSynthesis.speak(utterance);
  }

  function speakStop() {
    if ('speechSynthesis' in window) window.speechSynthesis.cancel();
  }

  function filteredWords() {
    const query = ui.libraryQuery.trim().toLowerCase();
    return WORDS.filter((word) => {
      const status = getWordStatus(word);
      if (ui.libraryFilter !== 'all' && status !== ui.libraryFilter) return false;
      if (!query) return true;
      return [word.word, word.meaning, word.topic, word.group, word.pos]
        .some((value) => String(value).toLowerCase().includes(query));
    });
  }

  function statusChip(word) {
    const status = getWordStatus(word);
    if (status === 'mastered') return '<span class="chip teal">已掌握</span>';
    if (status === 'red') return '<span class="chip red">红名单</span>';
    if (status === 'learning') return '<span class="chip gold">复习中</span>';
    return '<span class="chip">未学习</span>';
  }

  function renderLibrary() {
    const allFiltered = filteredWords();
    const visible = allFiltered.slice(0, ui.libraryLimit);
    const learned = getLearnedCount();
    const redCount = getRedWords().length;
    const mastered = getMasteredCount();

    main.innerHTML = `
      ${pageHeader('WORD LIBRARY', '800 词词库', '搜索、筛选并查看每个词的音标、用法与回忆记录。')}
      <div class="library-layout">
        <div>
          <div class="library-toolbar">
            <div class="search-wrap">
              <input id="librarySearch" type="search" value="${escapeHTML(ui.libraryQuery)}" placeholder="搜索英文、汉译或主题" autocomplete="off" enterkeyhint="search">
              <span class="search-icon" aria-hidden="true">⌕</span>
            </div>
            <div class="filter-row" aria-label="词库筛选">
              ${[
                ['all', '全部'],
                ['new', '未学习'],
                ['learning', '复习中'],
                ['red', '红名单'],
                ['mastered', '已掌握']
              ].map(([key, label]) => `<button class="filter-chip ${ui.libraryFilter === key ? 'active' : ''}" data-action="library-filter" data-filter="${key}">${label}</button>`).join('')}
            </div>
          </div>

          <div class="section-head">
            <h2>${allFiltered.length} 个结果</h2>
            <small>${visible.length < allFiltered.length ? `已显示 ${visible.length}` : '已显示全部'}</small>
          </div>

          ${
            visible.length
              ? `<div class="word-list">
                  ${visible.map((word) => `
                    <button class="word-list-item" data-action="open-word" data-word-id="${word.id}">
                      <span>
                        <h3>${escapeHTML(word.word)}<span class="ipa">${escapeHTML(word.ipa)}</span></h3>
                        <p>${escapeHTML(word.pos)} · ${escapeHTML(word.meaning)}</p>
                      </span>
                      <span class="word-list-meta">
                        ${statusChip(word)}
                        <small>D${word.day} · ${escapeHTML(word.topic)}</small>
                      </span>
                    </button>
                  `).join('')}
                </div>`
              : `<div class="empty-state"><strong>没有匹配的词</strong>换一个关键词或筛选条件试试。</div>`
          }
          ${
            visible.length < allFiltered.length
              ? `<div style="margin-top:16px;text-align:center"><button class="secondary-button" data-action="library-more">再显示 80 词</button></div>`
              : ''
          }
        </div>

        <aside class="library-aside">
          <section class="panel">
            <h3 class="panel-title"><span>词库总览</span><span class="chip coral">Core 800</span></h3>
            <div class="stats-strip" style="grid-template-columns:1fr 1fr">
              <div class="stat-box"><strong>${learned}</strong><span>已学习</span></div>
              <div class="stat-box"><strong>${mastered}</strong><span>已掌握</span></div>
              <div class="stat-box"><strong>${redCount}</strong><span>红名单</span></div>
              <div class="stat-box"><strong>${800 - learned}</strong><span>未学习</span></div>
            </div>
          </section>
          <section class="panel">
            <h3 class="panel-title"><span>词性缩写</span></h3>
            <p class="panel-copy">n. 名词 · v. 动词 · adj. 形容词 · adv. 副词。音标采用 General American IPA。</p>
          </section>
          <section class="panel">
            <h3 class="panel-title"><span>快速复习</span></h3>
            <p class="panel-copy">红名单中的词会优先出现在额外回测中；完整掌握需要完成全部 5 个固定复习阶段，且最近一次回忆评 2。</p>
            <button class="secondary-button" style="margin-top:12px;width:100%" data-action="${redCount ? 'start-red' : 'start-review'}" ${redCount || getDueWords().length ? '' : 'disabled'}>
              ${redCount ? `回测红名单 ${redCount}` : getDueWords().length ? `复习到期 ${getDueWords().length}` : '当前没有待复习词'}
            </button>
          </section>
        </aside>
      </div>
    `;
  }

  function openWordModal(wordId) {
    const word = WORD_BY_ID.get(wordId);
    if (!word) return;
    const card = state.cards[wordId] || null;
    const history = [...(card?.reviewHistory || [])].reverse().slice(0, 12);
    const status = getWordStatus(word);
    const historyHTML = history.length
      ? history.map((entry) => `
          <div class="history-item">
            <span>${formatDateTime(entry.at)} · ${escapeHTML(sessionLabel(entry.mode))}</span>
            <strong style="color:${entry.score === 2 ? 'var(--teal)' : entry.score === 1 ? 'var(--gold)' : 'var(--red)'}">${entry.score}</strong>
          </div>
        `).join('')
      : '<p class="panel-copy">还没有回忆记录。</p>';

    openModal(`
      <div class="modal-head">
        <div>
          <p class="eyebrow">D${word.day} · ${escapeHTML(word.group)} · ${escapeHTML(word.topic)}</p>
          <h2 class="modal-word">${escapeHTML(word.word)}</h2>
          <p class="modal-ipa">${escapeHTML(word.ipa)}</p>
        </div>
        <button class="icon-button" data-modal-close aria-label="关闭">×</button>
      </div>
      <div class="modal-body">
        <div class="stage-chips">
          ${statusChip(word)}
          ${card?.starred ? '<span class="chip gold">已收藏</span>' : ''}
          <span class="chip">${escapeHTML(word.pos)}</span>
        </div>
        <p class="modal-meaning">${escapeHTML(word.meaning)}</p>
        <p class="modal-example">${escapeHTML(word.example)}</p>
        <div class="button-row" style="margin-top:14px">
          <button class="secondary-button" data-action="speak" data-word="${escapeHTML(word.word)}">播放发音</button>
          <button class="secondary-button" data-action="studied-word" data-word-id="${word.id}">立即复习</button>
          <button class="ghost-button" data-action="toggle-star" data-word-id="${word.id}">${card?.starred ? '取消收藏' : '收藏'}</button>
        </div>
        <div class="settings-group">
          <label class="settings-label">个人笔记
            <textarea id="wordNotes" placeholder="记录搭配、易混词或自己的例句">${escapeHTML(card?.notes || '')}</textarea>
          </label>
          <button class="primary-button" style="margin-top:9px" data-action="save-word-notes" data-word-id="${word.id}">保存笔记</button>
        </div>
        <div class="settings-group">
          <h3 class="panel-title"><span>最近回忆</span><span class="chip">${card?.reviewHistory?.length || 0} 次</span></h3>
          <div class="history-list">${historyHTML}</div>
        </div>
      </div>
    `);
  }

  function openModal(content) {
    closeModal();
    modalRoot.innerHTML = `
      <div class="modal-backdrop" data-modal-close>
        <section class="modal" role="dialog" aria-modal="true" aria-label="详情">
          ${content}
        </section>
      </div>
    `;
    document.body.classList.add('modal-open');
  }

  function closeModal() {
    modalRoot.innerHTML = '';
    document.body.classList.remove('modal-open');
  }

  function plannedDayForDate(dateISO) {
    if (!state.settings.startDate) return null;
    const index = daysBetween(state.settings.startDate, dateISO);
    return index >= 0 && index < 20 ? index + 1 : null;
  }

  function dueCountForDate(dateISO) {
    return WORDS.filter((word) => {
      const card = state.cards[word.id];
      return card?.learnedAt && isDue(card, dateISO);
    }).length;
  }

  function renderCalendar() {
    const cursor = ui.calendarCursor;
    const year = cursor.getFullYear();
    const month = cursor.getMonth();
    const first = new Date(year, month, 1, 12, 0, 0, 0);
    const firstWeekday = first.getDay();
    const gridStart = new Date(year, month, 1 - firstWeekday, 12, 0, 0, 0);
    const studyDates = getStudyDates();
    const today = todayISO();
    const cells = [];

    for (let index = 0; index < 42; index++) {
      const date = new Date(gridStart);
      date.setDate(gridStart.getDate() + index);
      const iso = dateToISO(date);
      const inMonth = date.getMonth() === month;
      const plannedDay = plannedDayForDate(iso);
      const dueCount = dueCountForDate(iso);
      const studied = studyDates.has(iso);
      cells.push(`
        <button class="calendar-day ${inMonth ? '' : 'outside'} ${iso === today ? 'today' : ''} ${studied ? 'has-study' : ''} ${dueCount ? 'has-due' : ''} ${iso === ui.selectedCalendarDate ? 'selected' : ''}"
          data-action="calendar-select" data-date="${iso}" aria-label="${iso}${plannedDay ? `，计划 D${plannedDay}` : ''}${studied ? '，有学习记录' : ''}${dueCount ? `，${dueCount} 词到期` : ''}">
          ${plannedDay && inMonth ? `<span class="calendar-badge">D${plannedDay}</span>` : ''}
          <span class="calendar-num">${date.getDate()}</span>
        </button>
      `);
    }

    const selectedDate = ui.selectedCalendarDate;
    const selectedPlanDay = plannedDayForDate(selectedDate);
    const selectedWords = selectedPlanDay ? WORDS_BY_DAY.get(selectedPlanDay) || [] : [];
    const selectedTopic = selectedWords[0]?.topic || '';
    const selectedDue = selectedDate === today ? getDueWords() : WORDS.filter((word) => {
      const card = state.cards[word.id];
      return card?.learnedAt && isDue(card, selectedDate);
    });
    const selectedStudied = [...(getAllHistory().filter((entry) => localDateFromTimestamp(entry.at) === selectedDate))];

    const upcoming = [];
    for (let offset = 0; offset < 8; offset++) {
      const iso = addDaysISO(today, offset);
      const plan = plannedDayForDate(iso);
      const due = dueCountForDate(iso);
      if (plan || due) upcoming.push({ iso, plan, due });
    }

    main.innerHTML = `
      ${pageHeader('STUDY CALENDAR', '学习日历', '查看计划、到期复习和实际完成记录。')}
      <div class="panel">
        <div class="calendar-head">
          <button class="icon-button" data-action="calendar-prev" aria-label="上个月">←</button>
          <h2>${year} 年 ${month + 1} 月</h2>
          <button class="icon-button" data-action="calendar-next" aria-label="下个月">→</button>
        </div>
        <div class="calendar-grid" aria-label="月历">
          ${['日', '一', '二', '三', '四', '五', '六'].map((day) => `<span class="weekday">${day}</span>`).join('')}
          ${cells.join('')}
        </div>
        <div class="stage-chips" style="margin-top:14px">
          <span class="chip teal">有学习记录</span>
          <span class="chip gold">有词到期</span>
          <span class="chip coral">计划新学日</span>
        </div>
      </div>

      <section class="section">
        <div class="section-head">
          <h2>${formatLongDate(selectedDate)}</h2>
          <small>${selectedDate === today ? '今天' : '已选择'}</small>
        </div>
        <div class="panel">
          <div class="task-grid" style="grid-template-columns:1fr">
            <div class="task-card">
              <span class="task-icon">A</span>
              <span class="task-copy">
                <strong>${selectedPlanDay ? `计划新学 D${selectedPlanDay}` : '无计划新学'}</strong>
                <span>${selectedPlanDay ? escapeHTML(selectedTopic) : '这一天不在 20 天新词计划中'}</span>
              </span>
              <span class="task-arrow"></span>
            </div>
            <button class="task-card review" data-action="${selectedDate === today && selectedDue.length ? 'start-review' : 'noop'}">
              <span class="task-icon">R</span>
              <span class="task-copy">
                <strong>${selectedDue.length ? `${selectedDue.length} 词到期` : '无到期复习'}</strong>
                <span>${selectedDate === today ? '当前可进入复习' : '用于预览未来的到期量'}</span>
              </span>
              <span class="task-arrow">›</span>
            </button>
          </div>
          <p class="panel-copy" style="margin-top:13px">
            实际完成回忆 ${selectedStudied.length} 次${selectedStudied.length ? `，直接答对 ${selectedStudied.filter((entry) => entry.score === 2).length} 次` : ''}。
          </p>
        </div>
      </section>

      <section class="section">
        <div class="section-head"><h2>接下来 7 天</h2><small>计划 + 到期量</small></div>
        <div class="schedule-list">
          ${upcoming.length ? upcoming.map((item) => `
            <div class="schedule-item">
              <span class="schedule-date">${formatShortDate(item.iso)}</span>
              <span class="schedule-copy">
                <strong>${item.plan ? `D${item.plan} 计划新学 40 词` : '维护复习'}</strong>
                <span>${item.due ? `${item.due} 词按曲线到期` : '暂无到期'}</span>
              </span>
              <span class="schedule-count">${item.due ? item.due : '—'}</span>
            </div>
          `).join('') : '<div class="empty-state"><strong>暂无安排</strong>开始第一组新词后，这里会显示复习日期。</div>'}
        </div>
      </section>
    `;
  }

  function renderProgress() {
    const learned = getLearnedCount();
    const mastered = getMasteredCount();
    const red = getRedWords();
    const due = getDueWords();
    const accuracy = getAccuracy();
    const history = getAllHistory();
    const reviewCount = history.length;
    const week = [];
    let maxWeek = 1;
    for (let offset = 6; offset >= 0; offset--) {
      const iso = addDaysISO(todayISO(), -offset);
      const count = history.filter((entry) => localDateFromTimestamp(entry.at) === iso).length;
      week.push({ iso, count });
      maxWeek = Math.max(maxWeek, count);
    }

    const groups = [];
    for (let day = 1; day <= 20; day++) {
      const words = WORDS_BY_DAY.get(day) || [];
      const groupLearned = words.filter((word) => isLearned(word.id)).length;
      groups.push({ day, words, groupLearned });
    }

    const recent = [...state.sessions].reverse().slice(0, 8);

    main.innerHTML = `
      ${pageHeader('LEARNING STATS', '学习进度', '用可验证的记录判断掌握程度，而不是只看“看过多少词”。')}
      <div class="progress-hero">
        <div class="section-head">
          <h2>800 词总进度</h2>
          <span class="chip coral">${getStreak()} 天连续</span>
        </div>
        <div class="progress-total"><strong>${learned}</strong><span>/ 800 已进入学习</span></div>
        <p class="panel-copy">已完整掌握 ${mastered} 词，红名单 ${red.length} 词，今日到期 ${due.length} 词。</p>
        <div class="progress-track"><span style="width:${(learned / 800) * 100}%"></span></div>
        <div class="stats-strip" style="margin-top:18px">
          <div class="stat-box"><strong>${accuracy}%</strong><span>累计正确率</span></div>
          <div class="stat-box"><strong>${reviewCount}</strong><span>回忆次数</span></div>
          <div class="stat-box"><strong>${due.length}</strong><span>今日到期</span></div>
          <div class="stat-box"><strong>${red.length}</strong><span>红名单</span></div>
        </div>
      </div>

      <section class="section">
        <div class="section-head"><h2>近 7 天回忆量</h2><small>每次评分计 1 次</small></div>
        <div class="panel">
          <div class="chart">
            ${week.map((item) => `
              <div class="chart-column">
                <div class="chart-bar-wrap" title="${item.iso}: ${item.count} 次">
                  <span class="chart-bar" style="height:${Math.max(4, (item.count / maxWeek) * 100)}%"></span>
                </div>
                <small>${new Intl.DateTimeFormat('zh-CN', { weekday: 'short' }).format(parseISODate(item.iso))}</small>
              </div>
            `).join('')}
          </div>
        </div>
      </section>

      <div class="today-layout">
        <section class="section">
          <div class="section-head"><h2>20 组进度</h2><small>已学习词数</small></div>
          <div class="panel group-progress">
            ${groups.map((item) => `
              <div class="group-progress-item">
                <strong>D${item.day} ${escapeHTML(item.words[0]?.group || '')}</strong>
                <div class="mini-track"><span style="width:${(item.groupLearned / 40) * 100}%"></span></div>
                <small>${item.groupLearned}/40</small>
              </div>
            `).join('')}
          </div>
        </section>

        <aside class="sticky-column">
          <section class="section">
            <div class="section-head"><h2>最近学习记录</h2><small>${state.sessions.length} 次</small></div>
            <div class="schedule-list">
              ${recent.length ? recent.map((session) => `
                <div class="schedule-item">
                  <span class="schedule-date">${formatShortDate(session.date)}</span>
                  <span class="schedule-copy">
                    <strong>${escapeHTML(sessionLabel(session.mode))}</strong>
                    <span>直接答对 ${session.scores?.[2] || 0} / ${session.total}</span>
                  </span>
                  <span class="schedule-count">${session.total}</span>
                </div>
              `).join('') : '<div class="empty-state"><strong>还没有学习记录</strong>完成第一轮新词后会显示在这里。</div>'}
            </div>
          </section>
          <section class="panel">
            <h3 class="panel-title"><span>下一步</span></h3>
            <p class="panel-copy">${getNextLearningDay() ? `下一组是 D${getNextLearningDay()}，共 ${getNewWords().length} 个待学词。` : '新词已全部进入系统，接下来依靠到期复习巩固。'}</p>
            <div class="button-row" style="margin-top:12px">
              ${getNextLearningDay() ? '<button class="primary-button" data-action="start-new">继续新词</button>' : ''}
              ${due.length ? `<button class="secondary-button" data-action="start-review">复习 ${due.length} 词</button>` : ''}
            </div>
          </section>
        </aside>
      </div>
    `;
  }

  function syncPanelHTML() {
    const config = loadSyncConfig();
    if (auth) {
      return `
        <div class="sync-state">
          <span class="sync-dot" style="background:var(--teal)"></span>
          <span><strong>${escapeHTML(auth.user?.email || '已登录')}</strong><br>${ui.syncStatus === 'error' ? escapeHTML(ui.syncError) : '评分与笔记会自动推送到你的私有 Supabase 项目。'}</span>
        </div>
        <div class="button-row">
          <button class="primary-button" data-action="sync-now">立即同步</button>
          <button class="ghost-button" data-action="sync-logout">退出云同步</button>
        </div>
      `;
    }
    return `
      <p class="panel-copy">填写你自己的 Supabase 项目配置后登录。手机和电脑使用同一个账号即可同步；密码只用于本次登录，不会保存。</p>
      <div class="settings-group">
        <div class="field-grid">
          <label class="settings-label">Supabase URL
            <input id="syncUrl" type="url" value="${escapeHTML(config.url || '')}" placeholder="https://xxxx.supabase.co" autocomplete="off">
          </label>
          <label class="settings-label">anon public key
            <input id="syncKey" type="password" value="${escapeHTML(config.key || '')}" placeholder="eyJ..." autocomplete="off">
          </label>
          <label class="settings-label">邮箱
            <input id="syncEmail" type="email" value="${escapeHTML(config.email || '')}" placeholder="you@example.com" autocomplete="email">
          </label>
          <label class="settings-label">密码
            <input id="syncPassword" type="password" placeholder="至少 6 位" autocomplete="current-password">
          </label>
        </div>
      </div>
      <div class="button-row" style="margin-top:12px">
        <button class="primary-button" data-action="sync-login">登录并同步</button>
        <button class="secondary-button" data-action="sync-signup">注册账号</button>
        <button class="ghost-button" data-action="sync-help">配置说明</button>
      </div>
    `;
  }

  function renderSettings() {
    const installStandalone = window.matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
    main.innerHTML = `
      ${pageHeader('SETTINGS', '设置与同步', '学习数据默认保存在本机，也可以连接到你的私有云同步项目。')}
      <section class="panel">
        <h3 class="panel-title"><span>学习计划</span><span class="chip coral">20 天 · 800 词</span></h3>
        <div class="field-grid">
          <label class="settings-label">计划开始日期
            <input id="startDateSetting" type="date" data-setting="startDate" value="${escapeHTML(state.settings.startDate)}">
          </label>
          <label class="settings-label">发音速度 · <span id="voiceRateValue">${Number(state.settings.voiceRate).toFixed(2)}</span>
            <input id="voiceRateSetting" type="range" min="0.55" max="1.15" step="0.05" data-setting="voiceRate" value="${Number(state.settings.voiceRate)}">
          </label>
        </div>
        <p class="settings-help">修改开始日期只影响计划日历，不会改变已经产生的复习记录。</p>
        <div class="button-row" style="margin-top:12px">
          <button class="secondary-button" data-action="speak" data-word="Keep showing up, one word at a time.">测试发音</button>
        </div>
      </section>

      <section class="panel">
        <h3 class="panel-title">
          <span>iPhone 主屏幕与离线</span>
          <span class="chip ${installStandalone ? 'teal' : 'gold'}">${installStandalone ? '已在主屏幕' : '浏览器模式'}</span>
        </h3>
        <p class="panel-copy">PWA 首次打开并完成缓存后，可以离线背词。iPhone 请在 Safari 中点击“分享”→“添加到主屏幕”。</p>
        <div class="button-row" style="margin-top:12px">
          <button class="secondary-button" data-action="install-help">查看安装步骤</button>
        </div>
      </section>

      <section class="panel">
        <h3 class="panel-title">
          <span>手机＋电脑云同步</span>
          <span class="chip ${auth ? 'teal' : ''}">${auth ? '已连接' : '未连接'}</span>
        </h3>
        ${syncPanelHTML()}
      </section>

      <section class="panel">
        <h3 class="panel-title"><span>数据备份</span><span class="chip">建议每周一次</span></h3>
        <p class="panel-copy">JSON 可完整恢复学习状态；CSV 方便在 Excel 中查看。清理 Safari 网站数据前请先导出。</p>
        <div class="button-row" style="margin-top:12px">
          <button class="secondary-button" data-action="export-json">导出完整备份</button>
          <button class="secondary-button" data-action="export-csv">导出进度 CSV</button>
          <button class="ghost-button" data-action="import-json">导入备份</button>
        </div>
        <input id="importFile" type="file" accept="application/json,.json" hidden>
      </section>

      <section class="panel">
        <h3 class="panel-title"><span>关于数据</span><span class="chip">Core 800 v1</span></h3>
        <p class="panel-copy">词库共 800 词，包含美式音标、词性、汉译和例句。数据模型保留 book 字段，后续可在同一应用中加入 IELTS 词库、作文主题词和听力场景词。</p>
      </section>

      <section class="panel">
        <h3 class="panel-title"><span>重置</span></h3>
        <p class="panel-copy">重置会删除本机的学习记录，不会删除云同步配置。建议先导出备份。</p>
        <button class="danger-button" style="margin-top:12px" data-action="reset-data">清空本机学习记录</button>
      </section>
    `;
  }

  function openInstallHelp() {
    const canPrompt = Boolean(ui.deferredInstallPrompt);
    openModal(`
      <div class="modal-head">
        <div>
          <p class="eyebrow">INSTALL</p>
          <h2>添加到主屏幕</h2>
        </div>
        <button class="icon-button" data-modal-close aria-label="关闭">×</button>
      </div>
      <div class="modal-body">
        <p><strong>iPhone：</strong>使用 Safari 打开本页面 → 点击底部“分享”按钮 → 向下找到“添加到主屏幕” → 点击“添加”。</p>
        <p><strong>电脑：</strong>Chrome 或 Edge 地址栏右侧出现安装图标时，点击安装；也可以使用浏览器菜单中的“安装应用”。</p>
        <p>添加到主屏幕后，打开应用会进入独立窗口。首次联网打开后，应用外壳和 800 词会缓存到本机。</p>
        ${canPrompt ? '<button class="primary-button" data-action="install-now">立即安装</button>' : ''}
      </div>
    `);
  }

  function openSyncHelp() {
    openModal(`
      <div class="modal-head">
        <div>
          <p class="eyebrow">SUPABASE</p>
          <h2>云同步配置</h2>
        </div>
        <button class="icon-button" data-modal-close aria-label="关闭">×</button>
      </div>
      <div class="modal-body">
        <p><strong>1.</strong> 在 supabase.com 新建一个仅自己使用的项目。</p>
        <p><strong>2.</strong> 打开 SQL Editor，执行项目目录中 <code>supabase/schema.sql</code> 的全部内容。</p>
        <p><strong>3.</strong> 在 Project Settings → API 复制 Project URL 和 anon public key，填入设置页。</p>
        <p><strong>4.</strong> 注册账号并登录。iPhone 和电脑填写同一项目配置并登录同一账号，即可双向同步。</p>
        <p>请只使用 anon public key，不要填写 service_role key。anon key 本身可以公开，真正的数据权限由数据库 Row Level Security 控制。</p>
        <div class="code-block">create table public.study_snapshots (
  user_id uuid primary key references auth.users(id) on delete cascade,
  payload jsonb not null,
  updated_at timestamptz not null default now()
);

alter table public.study_snapshots enable row level security;

create policy "users read own snapshot"
on public.study_snapshots for select
using (auth.uid() = user_id);

create policy "users insert own snapshot"
on public.study_snapshots for insert
with check (auth.uid() = user_id);

create policy "users update own snapshot"
on public.study_snapshots for update
using (auth.uid() = user_id)
with check (auth.uid() = user_id);</div>
      </div>
    `);
  }

  function downloadBlob(filename, content, type) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  }

  function exportJSON() {
    const payload = {
      app: 'core800-pwa',
      exportedAt: new Date().toISOString(),
      state
    };
    downloadBlob(
      `core800-backup-${todayISO()}.json`,
      JSON.stringify(payload, null, 2),
      'application/json'
    );
    showToast('完整备份已导出。');
  }

  function csvCell(value) {
    const text = String(value ?? '');
    return `"${text.replaceAll('"', '""')}"`;
  }

  function exportCSV() {
    const headers = [
      '学习日', '组别', '主题', '序号', '英文', '美式音标', '词性',
      '汉译', '例句', '首次学习日期', '已完成复习阶段', '最近评分',
      '错误次数', '下次红名单复习', '收藏', '笔记', '最近复习时间'
    ];
    const lines = [headers.map(csvCell).join(',')];
    for (const word of WORDS) {
      const card = state.cards[word.id] || {};
      lines.push([
        word.day,
        word.group,
        word.topic,
        word.no,
        word.word,
        word.ipa,
        word.pos,
        word.meaning,
        word.example,
        card.learnedAt || '',
        (card.completedStages || []).join('/'),
        card.lastScore ?? '',
        card.errorCount || 0,
        card.redDueAt || '',
        card.starred ? '是' : '',
        card.notes || '',
        card.lastReviewedAt || ''
      ].map(csvCell).join(','));
    }
    downloadBlob(
      `core800-progress-${todayISO()}.csv`,
      `\uFEFF${lines.join('\r\n')}\r\n`,
      'text/csv;charset=utf-8'
    );
    showToast('进度 CSV 已导出。');
  }

  function importBackupFromFile(file) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result));
        const imported = normalizeState(parsed.state || parsed);
        if (!imported.cards || typeof imported.cards !== 'object') throw new Error('备份中没有有效学习记录');
        state = mergeStates(state, imported);
        state.updatedAt = new Date().toISOString();
        saveState();
        renderSettings();
        queueSync();
        showToast('备份已合并导入。');
      } catch (error) {
        showToast(`导入失败：${error.message || String(error)}`, 4500);
      }
    };
    reader.readAsText(file);
  }

  function resetLocalData() {
    const confirmed = window.confirm('确定清空本机学习记录吗？建议先导出备份。云同步配置和登录状态会保留。');
    if (!confirmed) return;
    state = defaultState();
    saveState();
    ui.session = null;
    document.body.classList.remove('studying');
    renderSettings();
    queueSync();
    showToast('本机学习记录已清空。');
  }

  function updateInstallBanner() {
    const standalone = window.matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
    const dismissed = localStorage.getItem(INSTALL_DISMISSED_KEY) === '1';
    installBanner.hidden = standalone || dismissed || Boolean(ui.session);
  }

  function startWordSession(wordId) {
    if (!WORD_BY_ID.has(wordId)) return;
    closeModal();
    speakStop();
    ui.session = {
      id: uid(),
      mode: 'single',
      words: [wordId],
      index: 0,
      revealed: false,
      startedAt: new Date().toISOString(),
      scores: [0, 0, 0],
      complete: false
    };
    document.body.classList.add('studying');
    renderStudy();
  }

  async function handleSyncLogin(signup = false) {
    const url = main.querySelector('#syncUrl')?.value || '';
    const key = main.querySelector('#syncKey')?.value || '';
    const email = main.querySelector('#syncEmail')?.value || '';
    const password = main.querySelector('#syncPassword')?.value || '';
    if (!url || !key || !email || !password) {
      showToast('请完整填写 Supabase URL、anon key、邮箱和密码。');
      return;
    }
    saveSyncConfig({ url, key, email });
    ui.syncStatus = 'syncing';
    updateSyncPill();
    try {
      const success = await authenticate(email, password, signup);
      if (success) {
        await syncNow();
        render();
      } else {
        ui.syncStatus = 'local';
        updateSyncPill();
        renderSettings();
      }
    } catch (error) {
      ui.syncStatus = 'error';
      ui.syncError = error.message || String(error);
      updateSyncPill();
      showToast(`云同步登录失败：${ui.syncError}`, 5200);
      renderSettings();
    }
  }

  function handleInput(event) {
    const target = event.target;
    if (target.id === 'librarySearch') {
      const selection = target.selectionStart;
      ui.libraryQuery = target.value;
      ui.libraryLimit = 80;
      renderLibrary();
      const input = document.getElementById('librarySearch');
      if (input) {
        input.focus();
        input.setSelectionRange(selection, selection);
      }
      return;
    }
    if (target.id === 'voiceRateSetting') {
      const value = Number(target.value);
      const label = document.getElementById('voiceRateValue');
      if (label) label.textContent = value.toFixed(2);
    }
  }

  function handleChange(event) {
    const target = event.target;
    if (target.id === 'importFile') {
      importBackupFromFile(target.files?.[0]);
      target.value = '';
      return;
    }
    if (target.dataset.setting === 'startDate') {
      if (!target.value) return;
      state.settings.startDate = target.value;
      state.settingsUpdatedAt = new Date().toISOString();
      state.updatedAt = state.settingsUpdatedAt;
      saveState();
      queueSync();
      showToast('计划开始日期已更新。');
      return;
    }
    if (target.dataset.setting === 'voiceRate') {
      state.settings.voiceRate = clamp(Number(target.value), 0.5, 1.25);
      state.settingsUpdatedAt = new Date().toISOString();
      state.updatedAt = state.settingsUpdatedAt;
      saveState();
      queueSync();
    }
  }

  async function handleAction(action, target) {
    if (action === 'start-new') {
      startStudy('new');
    } else if (action === 'start-review') {
      startStudy('review');
    } else if (action === 'start-red') {
      startStudy('red');
    } else if (action === 'start-next-new') {
      exitStudy();
      startStudy('new');
    } else if (action === 'exit-study') {
      exitStudy();
    } else if (action === 'reveal') {
      revealStudyAnswer();
    } else if (action === 'grade') {
      gradeCurrentWord(Number(target.dataset.score));
    } else if (action === 'speak') {
      speak(target.dataset.word || '');
    } else if (action === 'go-library') {
      setView('library');
    } else if (action === 'go-calendar') {
      setView('calendar');
    } else if (action === 'go-progress') {
      setView('progress');
    } else if (action === 'go-settings') {
      setView('settings');
    } else if (action === 'library-filter') {
      ui.libraryFilter = target.dataset.filter || 'all';
      ui.libraryLimit = 80;
      renderLibrary();
    } else if (action === 'library-more') {
      ui.libraryLimit += 80;
      renderLibrary();
    } else if (action === 'open-word') {
      openWordModal(target.dataset.wordId);
    } else if (action === 'toggle-star') {
      toggleStar(target.dataset.wordId);
      openWordModal(target.dataset.wordId);
      showToast('收藏状态已更新。');
    } else if (action === 'save-word-notes') {
      const notes = document.getElementById('wordNotes')?.value || '';
      saveNotes(target.dataset.wordId, notes);
      openWordModal(target.dataset.wordId);
      showToast('笔记已保存。');
    } else if (action === 'studied-word') {
      startWordSession(target.dataset.wordId);
    } else if (action === 'calendar-prev') {
      ui.calendarCursor = new Date(ui.calendarCursor.getFullYear(), ui.calendarCursor.getMonth() - 1, 1, 12);
      renderCalendar();
    } else if (action === 'calendar-next') {
      ui.calendarCursor = new Date(ui.calendarCursor.getFullYear(), ui.calendarCursor.getMonth() + 1, 1, 12);
      renderCalendar();
    } else if (action === 'calendar-select') {
      ui.selectedCalendarDate = target.dataset.date;
      renderCalendar();
    } else if (action === 'install-help') {
      openInstallHelp();
    } else if (action === 'install-now') {
      if (ui.deferredInstallPrompt) {
        ui.deferredInstallPrompt.prompt();
        await ui.deferredInstallPrompt.userChoice;
        ui.deferredInstallPrompt = null;
        closeModal();
      }
    } else if (action === 'sync-help') {
      openSyncHelp();
    } else if (action === 'sync-login') {
      await handleSyncLogin(false);
    } else if (action === 'sync-signup') {
      await handleSyncLogin(true);
    } else if (action === 'sync-now') {
      await syncNow();
    } else if (action === 'sync-logout') {
      saveAuth(null);
      ui.syncStatus = 'local';
      renderSettings();
      showToast('已退出云同步，本机记录仍然保留。');
    } else if (action === 'export-json') {
      exportJSON();
    } else if (action === 'export-csv') {
      exportCSV();
    } else if (action === 'import-json') {
      document.getElementById('importFile')?.click();
    } else if (action === 'reset-data') {
      resetLocalData();
    } else if (action === 'noop') {
      showToast(target.closest('.task-card')?.classList.contains('review') ? '未来日期只能预览到期量。' : '');
    }
  }

  document.addEventListener('click', async (event) => {
    const closeButton = event.target.closest('[data-modal-close]');
    if (event.target.classList.contains('modal-backdrop') || closeButton?.tagName === 'BUTTON') {
      closeModal();
      return;
    }

    const navButton = event.target.closest('[data-nav]');
    if (navButton) {
      event.preventDefault();
      setView(navButton.dataset.nav);
      return;
    }

    const actionButton = event.target.closest('[data-action]');
    if (!actionButton) return;
    event.preventDefault();
    await handleAction(actionButton.dataset.action, actionButton);
  });

  main.addEventListener('input', handleInput);
  main.addEventListener('change', handleChange);

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      if (modalRoot.innerHTML) {
        closeModal();
      } else if (ui.session) {
        exitStudy();
      }
      return;
    }
    if (!ui.session || ui.session.complete || event.target.matches('input, textarea, select')) return;
    if (event.code === 'Space') {
      event.preventDefault();
      if (!ui.session.revealed) revealStudyAnswer();
      return;
    }
    if (ui.session.revealed && ['0', '1', '2'].includes(event.key)) {
      event.preventDefault();
      gradeCurrentWord(Number(event.key));
    }
  });

  window.addEventListener('online', () => {
    updateOnlineStatus();
    if (auth) syncNow({ silent: true });
  });
  window.addEventListener('offline', updateOnlineStatus);
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible' && auth && navigator.onLine) {
      syncNow({ silent: true });
    }
  });

  window.addEventListener('beforeinstallprompt', (event) => {
    event.preventDefault();
    ui.deferredInstallPrompt = event;
    updateInstallBanner();
  });

  window.addEventListener('appinstalled', () => {
    ui.deferredInstallPrompt = null;
    installBanner.hidden = true;
    showToast('Core 800 已安装到设备。');
  });

  document.getElementById('installHelpButton')?.addEventListener('click', openInstallHelp);
  document.getElementById('dismissInstall')?.addEventListener('click', () => {
    localStorage.setItem(INSTALL_DISMISSED_KEY, '1');
    installBanner.hidden = true;
  });

  async function initialize() {
    updateOnlineStatus();
    updateSyncPill();
    render();
    if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) {
      try {
        await navigator.serviceWorker.register('./service-worker.js');
      } catch (error) {
        console.warn('Service worker registration failed', error);
      }
    }
    if (navigator.storage?.persist) {
      navigator.storage.persist().catch(() => {});
    }
    if (auth && navigator.onLine) {
      setTimeout(() => syncNow({ silent: true }), 900);
    }
  }

  initialize();
})();
