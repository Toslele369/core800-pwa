// Public deployment configuration.
// These two values are safe to expose in a PWA. Never put the service_role key here.
window.CORE800_CONFIG = {
  supabaseUrl: 'https://jtztlxapqgbrscngjrlx.supabase.co',
  supabaseAnonKey: 'sb_publishable_zm3Q6RgnMXttRXjkbgx3Ag_NpIp-W5A'
};
